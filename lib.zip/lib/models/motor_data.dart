class MotorData {

  final double voltage;
  final double current;
  final double rpm;
  final double temperature;
  final double vibration;

  const MotorData({
    required this.voltage,
    required this.current,
    required this.rpm,
    required this.temperature,
    required this.vibration,
  });

  factory MotorData.fromJson(Map<String,dynamic> json){

    return MotorData(
      voltage: json['voltage'].toDouble(),
      current: json['current'].toDouble(),
      rpm: json['rpm'].toDouble(),
      temperature: json['temperature'].toDouble(),
      vibration: json['vibration'].toDouble(),
    );

  }

}
