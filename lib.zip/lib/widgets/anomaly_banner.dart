import 'package:flutter/material.dart';

class AnomalyBanner extends StatelessWidget {

  final String message;

  const AnomalyBanner({
    super.key,
    required this.message
  });

  @override
  Widget build(BuildContext context){

    return Container(

      width: double.infinity,

      padding: EdgeInsets.all(12),

      color: Colors.orange,

      child: Text(

        message,

        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold
        ),

        textAlign: TextAlign.center,

      ),

    );

  }

}